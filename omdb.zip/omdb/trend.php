<?php
  $nav_selected = "TREND";
  $left_buttons = "NO";
  $left_selected = "";

  include("./nav.php");
  
 ?>

 <div class="right-content">
    <div class="container">

      <h3 style = "color: #01B0F1;">Trend (TO BE DONE LATER)</h3>

    </div>
</div>

<?php include("./footer.php"); ?>
